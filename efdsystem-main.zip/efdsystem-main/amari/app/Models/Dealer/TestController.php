<?php

namespace App\Models\Dealer;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TestController extends Model
{
    use HasFactory;
}
